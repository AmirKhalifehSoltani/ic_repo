<?php $__env->startSection('content'); ?>
    <div>
        <ul class="nav nav-tabs border">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#daily">روزانه</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#weekly">هفتگی</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#monthly">ماهانه</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#yearly">سالانه</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#by_date">بر اساس تاریخ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#all_times">کل</a>
            </li>
        </ul>
        <div class="time-range">
            <form role="form">
                <div class="form-body">
                    <div class="form-group row">
                        
                        
                        
                        <label class="col-md-1">بازه زمانی</label>
                        <div class="col-md-3">
                            <select class="form-control">
                                <option value="3">همه</option>
                                <option value="0">صبح</option>
                                <option value="1">عصر</option>
                                <option value="2">شب</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-calendar-check-o"></i>
                                            </span>
                                <input type="text" class="persian-datepicker-from form-control" placeholder="از تاریخ">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-calendar-times-o"></i>
                                            </span>
                                <input type="text" class="persian-datepicker-from form-control" placeholder="تا تاریخ">
                            </div>
                        </div>
                    </div><!-- /.form-group -->
                </div>
            </form>
        </div>
        <div class="tab-content">
            <div id="daily" class="tab-pane fade active show">
                1
            </div>
            <div id="weekly" class="tab-pane fade">
                2
            </div>
            <div id="monthly" class="tab-pane fade">
                <canvas id="monthlyChart" class="min-height-600"></canvas>
            </div>
            <div id="yearly" class="tab-pane fade">
                4
            </div>
            <div id="by_date" class="tab-pane fade">
                5
            </div>
            <div id="all_times" class="tab-pane fade">
                6
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-new\htdocs\ccounter\resources\views/frontend/statistics/stats.blade.php ENDPATH**/ ?>