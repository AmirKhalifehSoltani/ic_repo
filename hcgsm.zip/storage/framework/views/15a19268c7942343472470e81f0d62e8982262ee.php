<div class="col-md-6 offset-md-3">
    <form id="simple-form" role="form" method="post" action="">
        <?php echo e(csrf_field()); ?>

        <div class="form-body">
            <div class="form-group">
                <label for="counter_name">نام شمارنده <small> (الزامی)</small></label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-user"></i>
                    </span>
                    <input id="counter_name" class="form-control" name="counter_name" type="text"
                           value="<?php echo e(old('counter_name', isset($counter_item)? $counter_item->name: '')); ?>">
                </div>
                <label for="sim_number">شماره سیم‌کارت<small> (الزامی)</small></label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-user"></i>
                    </span>
                    <input id="sim_number" class="form-control" name="sim_number" type="text"
                           value="<?php echo e(old('sim_number', isset($counter_item)? $counter_item->sim_number: '')); ?>">
                </div>
                <br>
                <?php if($branches && count($branches) > 0): ?>
                    <div class="form-group">
                        <label>انتخاب شعبه</label>
                        <div class="input-group">
                            <span class="input-group-addon">
                                <i class="icon-options"></i>
                            </span>
                            <select class="form-control" name="counter_branch">
                                <option value="0">
                                    شعبه را انتخاب کنید.
                                </option>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($branch->branch_id); ?>" <?php echo e(isset($counter_item) && $counter_item->counter_branch_id === $branch->branch_id ? 'selected': ''); ?>>
                                        <?php echo e($branch->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div><!-- /.input-group -->
                    </div>
                <?php else: ?>
                    <p>شعبه ای ثبت نشده است.</p>
                    <a href="<?php echo e(route('branches.create')); ?>" class="btn btn-primary btn-block">ثبت شعبه</a>
                <?php endif; ?>
            </div>
        </div>
        <hr>
        <div class="form-actions">
            <button type="submit" class="btn btn-lg btn-success col-md-6 offset-md-3">
                <i class="icon-check"></i>
                ذخیره اطلاعات
            </button>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\ccounter\resources\views/frontend/counters/form.blade.php ENDPATH**/ ?>