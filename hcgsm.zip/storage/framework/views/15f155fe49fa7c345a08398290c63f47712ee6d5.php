<?php $__currentLoopData = $materialsheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materialsheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    if (isset($materialsheet->type) && $materialsheet->type === 1) {
        $materialsheet_type_name = 'ورود';
    } elseif (isset($materialsheet->type) && $materialsheet->type === 2) {
        $materialsheet_type_name = 'خروج';
    }
//    dd($materialsheet->user);
    if($materialsheet) {
        if(!$materialsheet->user) {
            $matsheet_user_name = 'نامعلوم';
        } elseif($materialsheet->user) {
            $matsheet_user_name = $materialsheet->user->first_name.' '.$materialsheet->user->last_name;
        }
    }
//    echo $matsheet_user_name;
    ?>
    <script> var myDate = new persianDate.unix(<?php echo e($materialsheet->created_at->timestamp); ?>).format("dddd, DD MMMM YY, H:mm:ss") </script>
    <tr>
        <td>
            <script>document.write(myDate)</script>
        </td>
        <td><?php echo e($materialsheet_type_name); ?></td>
        <td><?php echo e($materialsheet->warehouse->name); ?></td>
        <td><?php echo e($materialsheet->material->name); ?></td>
        <td><?php echo e($materialsheet->stock); ?> (<?php echo e($materialsheet->material->unit->name); ?>)</td>
        <td><?php echo e(isset($matsheet_user_name)? $matsheet_user_name: ''); ?></td>
        <?php if(\Illuminate\Support\Facades\Auth::user()->role === 1): ?>
            <td><?php echo $__env->make('admin.materialsheets.operations', $materialsheet, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
        <?php endif; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/materialsheets/row.blade.php ENDPATH**/ ?>