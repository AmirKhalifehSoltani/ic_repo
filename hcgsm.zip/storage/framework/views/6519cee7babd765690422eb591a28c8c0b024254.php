<div class="col-md-6 offset-md-3">
    <form id="simple-form" role="form" method="post" action="">
        <?php echo e(csrf_field()); ?>

        <div class="form-body">
            <div class="form-group">
                <label for="device_name">نام دستگاه
                    <small> (الزامی)</small>
                </label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-user"></i>
                    </span>
                    <input id="device_name" class="form-control" name="device_name" type="text"
                           value="<?php echo e(old('device_name', isset($deviceItem)? $deviceItem->name: '')); ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="device_code">کد دستگاه
                    <small> (الزامی)</small>
                </label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-barcode"></i>
                    </span>
                    <input id="device_code" class="form-control" name="device_code" type="text"
                           value="<?php echo e(old('device_code', isset($deviceItem)? $deviceItem->code: '')); ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="device_user">کاربر دستگاه
                    <small> (الزامی)</small>
                </label>
                <div class="input-group">
                    <select name="device_user" id="device_user" class="form-control select2">
                        <option value="0">کاربر را انتخاب کنید.</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e(isset($deviceItem) && $deviceItem->user->id == $user->id? 'selected': ''); ?>><?php echo e($user->first_name.' '.$user->last_name.' ( '.$user->user_name.' )'); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <hr>
        <div class="form-actions">
            <button type="submit" class="btn btn-lg btn-success col-md-6 offset-md-3">
                <i class="icon-check"></i>
                ذخیره اطلاعات
            </button>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\hcgsm\resources\views/admin/devices/form.blade.php ENDPATH**/ ?>