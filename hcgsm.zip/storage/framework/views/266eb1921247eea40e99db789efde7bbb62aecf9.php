<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.materialsheets.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/materialsheets/create.blade.php ENDPATH**/ ?>