<?php $__env->startSection('content'); ?>
    <h2 class="text-center m-b-20">وارد شوید</h2>
    <hr>
    <?php if(session('loginError')): ?>
        <div class="alert alert-info">
            <p><?php echo e(session('loginError')); ?></p>
        </div>
    <?php endif; ?>
    <?php if(isset($msg)): ?>
        <div class="alert alert-info">
            <p><?php echo e($msg); ?></p>
        </div>
    <?php endif; ?>
    <form id="form" class="m-t-30 m-b-30" action="<?php echo e(route('dosignin')); ?>" method="POST" role="form">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="user_name" class="sr-only">نام کاربری</label>
            <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-user"></i>
                    </span>
                <input id="user_name" class="form-control ltr text-left" type="user_name" name="user_name" required>
            </div><!-- /.input-group -->
        </div><!-- /.form-group -->
        <div class="form-group">
            <label for="password" class="sr-only">رمز عبور</label>
            <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-key"></i>
                    </span>
                <input id="password" class="form-control ltr text-left" name="password" type="password" minlength="5" required>
            </div><!-- /.input-group -->
        </div><!-- /.form-group -->
        <div class="form-group">
            <div class="input-group">
                <div>
                    <div class="g-recaptcha" data-sitekey="<?php echo e(env('CAPTCHA_SITE_KEY')); ?>"></div>
                </div>
            </div>
        </div>
        <p>
            <button class="btn btn-info btn-block" type="submit">
                <i class="icon-login"></i>
                ورود
            </button>
        </p>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hcgsm\resources\views/frontend/users/signin.blade.php ENDPATH**/ ?>