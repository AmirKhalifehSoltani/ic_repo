<?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($device->name); ?></td>
        <td><?php echo e($device->code); ?></td>
        <?php $user = $device->user ?>
        <td><?php echo e(isset($user)? $user->first_name.' '.$user->last_name.' ( '.$user->user_name.' )': ''); ?></td>
        <td><?php echo $__env->make('admin.devices.operations', $device, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\hcgsm\resources\views/admin/devices/row.blade.php ENDPATH**/ ?>