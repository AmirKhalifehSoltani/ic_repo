<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped" id="admin_users_table">
            <thead>
            <tr>
                <th>ردیف</th>
                <th>نام</th>
                <th>نام خانوادگی</th>
                <th>نام کاربری</th>
                <th>نقش</th>
                <th>ایمیل</th>
                <th>شعبه‌ها</th>
                <td>عملیات</td>
            </tr>
            </thead>
            <tbody>
            <?php if($users && count($users) > 0): ?>
                <?php echo $__env->make('admin.users.row', $users, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ccounter\resources\views/admin/users/equipcats.blade.php ENDPATH**/ ?>