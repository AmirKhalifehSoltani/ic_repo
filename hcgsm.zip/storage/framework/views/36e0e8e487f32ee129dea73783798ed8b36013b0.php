<?php $__env->startSection('content'); ?>
    <div class="col-md-6 offset-md-3">
        <?php echo $__env->make('frontend.partials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form id="simple-form" role="form" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-body">
                <div class="form-group">
                    <label for="first_name">نام <small> (الزامی)</small></label>
                    <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-user"></i>
                    </span>
                        <input id="first_name" class="form-control" name="first_name" type="text" value="<?php echo e(old('first_name')); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="last_name">نام خانوادگی <small> (الزامی)</small></label>
                    <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-user"></i>
                    </span>
                        <input id="last_name" class="form-control" name="last_name" type="text" value="<?php echo e(old('last_name')); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="user_name">نام کاربری <small> (الزامی)</small></label>
                    <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-user"></i>
                    </span>
                        <input id="user_name" class="form-control" name="user_name" type="text" value="<?php echo e(old('user_name')); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="email">ایمیل</label></label>
                    <div class="input-group">
                <span class="input-group-addon">
                    <i class="icon-envelope"></i>
                </span>
                        <input id="email" class="form-control ltr text-left" type="email" name="email" value="<?php echo e(old('email')); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="password">رمز عبور<small> (الزامی، حداقل ۴ و حداکثر ۱۲ کارکتر) </small></label>
                    <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-key"></i>
                    </span>
                        <input type="password" id="password" minlength="5" class="form-control" name="password">
                    </div>
                </div>
            </div>
            <hr>
            <div class="form-actions">
                <button type="submit" class="btn btn-lg btn-success col-md-6 offset-md-3">
                    <i class="icon-check"></i>
                    ثبت نام
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-new\htdocs\ccounter\resources\views/frontend/users/registeration.blade.php ENDPATH**/ ?>