<?php $__currentLoopData = $materialreports_full_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materialreport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($materialreport->matname); ?></td>
        <td><?php echo e($materialreport->matcatname); ?></td>
        <td><?php echo e($materialreport->warehousename); ?></td>
        <td><?php echo e($materialreport->report_stock); ?> (<?php echo e($materialreport->unitname); ?>)</td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/materialreports/row.blade.php ENDPATH**/ ?>