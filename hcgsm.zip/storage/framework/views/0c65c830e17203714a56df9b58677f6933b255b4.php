<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped" id="admin_users_table">
            <thead>
            <tr>
                <th>نام شعبه</th>
                <th>دستگاه‌ها</th>
                <td>عملیات</td>
            </tr>
            </thead>
            <tbody>
            <?php if($branches && count($branches) > 0): ?>
                <?php echo $__env->make('frontend.branches.row', $branches, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-new\htdocs\ccounter\resources\views/frontend/branches/list.blade.php ENDPATH**/ ?>