<form method="get" id="simple-form" role="form">
    <div class="form-row">
        <div class="form-group col-md-3">
            <input type="text" name="search" id="search" class="form-control" placeholder="جستجو" value="<?php echo e(isset($search_phrase) && $search_phrase != ''? $search_phrase : ''); ?>"/>
        </div>
        <div class="form-group col-md-3">
            <select name="equipcat" id="equipcat" class="form-control select2">
                <option value="0">انتخاب دسته تجهیزات</option>
                <?php $__currentLoopData = $equipment_reports_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment_reports_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($equipment_reports_category->equipcatid); ?>" <?php echo e(isset($equipcat_id) && $equipcat_id == $equipment_reports_category->equipcatid ? 'selected' : ''); ?>><?php echo e($equipment_reports_category->equipcatname); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-md-3">
            <select name="warehouse" id="warehouse" class="form-control select2">
                <option value="0" selected>انتخاب انبار</option>
                <?php $__currentLoopData = $equipment_reports_warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment_reports_warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($equipment_reports_warehouse->warehouse->id); ?>" <?php echo e(isset($warehouse_id) && $warehouse_id == $equipment_reports_warehouse->warehouse->id ? 'selected' : ''); ?>><?php echo e($equipment_reports_warehouse->warehouse->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-md-3">
            <select name="techspec" id="techspec" class="form-control select2">
                <option value="0" selected>انتخاب مشخصه فنی</option>
                <?php $__currentLoopData = $equipment_reports_techspecs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment_reports_techspec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($equipment_reports_techspec->techspecid); ?>" <?php echo e(isset($techspec_id) && $techspec_id == $equipment_reports_techspec->techspecid ? 'selected' : ''); ?>><?php echo e($equipment_reports_techspec->techspecname); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-md-3">
            <select name="lookspec" id="lookspec" class="form-control select2">
                <option value="0" selected>انتخاب مشخصه ظاهری</option>
                <?php $__currentLoopData = $equipment_reports_lookspecs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment_reports_lookspec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($equipment_reports_lookspec->lookspecid); ?>" <?php echo e(isset($lookspec_id) && $lookspec_id == $equipment_reports_lookspec->lookspecid ? 'selected' : ''); ?>><?php echo e($equipment_reports_lookspec->lookspecname); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-md-3">
            <select name="health" id="health" class="form-control select2">
                <option value="0" selected>انتخاب وضعیت سلامتی</option>
                <?php $__currentLoopData = $equipment_reports_healthstatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment_reports_health): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($equipment_reports_health->healthid); ?>" <?php echo e(isset($health_id) && $health_id == $equipment_reports_health->healthid ? 'selected' : ''); ?>><?php echo e($equipment_reports_health->healthname); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-md-3">
            <button type="submit" class="btn btn-primary btn-block">
                <i class="fa fa-search"></i>
                جستجو
            </button>
        </div>
    </div>
</form><?php /**PATH /home/fbcofmsf/fbportal.farazband.com/resources/views/admin/equipmentreports/searchfilter_form.blade.php ENDPATH**/ ?>