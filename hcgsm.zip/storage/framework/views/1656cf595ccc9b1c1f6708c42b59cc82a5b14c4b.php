<?php if(session('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e(session('success')); ?></p>
    </div>
<?php endif; ?>
<?php if(session('danger')): ?>
    <div class="alert alert-danger">
        <p><?php echo e(session('danger')); ?></p>
    </div>
<?php endif; ?>
<?php /**PATH /home/fbcofmsf/fbportal.farazband.com/resources/views/layouts/partials/notifications.blade.php ENDPATH**/ ?>