<?php $__currentLoopData = $equipcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($equipcat->name); ?></td>
        <td><?php echo $__env->make('admin.equipcats.operations', $equipcat, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/equipcats/row.blade.php ENDPATH**/ ?>