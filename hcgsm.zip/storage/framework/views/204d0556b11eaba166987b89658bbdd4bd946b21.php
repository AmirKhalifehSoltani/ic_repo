<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped" id="admin_users_table">
            <thead>
            <tr>
                <th>نام تجهیزات (فنی - ظاهری - سلامتی)</th>
                <th>نام دسته</th>
                <th>واحد</th>
                <th>کد</th>
                <th>عملیات</th>
            </tr>
            </thead>
            <tbody>
            <?php if($equipments && count($equipments) > 0): ?>
                <?php echo $__env->make('admin.equipments.row', $equipments, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/equipments/equipments.blade.php ENDPATH**/ ?>