<div class="col-md-6 offset-md-3">
    <form id="simple-form" role="form" method="post" action="">
        <?php echo e(csrf_field()); ?>

        <div class="form-body">
            <div class="form-group">
                <label for="healthstatus_name">نام وضعیت سلامتی <small> (الزامی)</small></label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-user"></i>
                    </span>
                    <input id="healthstatus_name" class="form-control" name="healthstatus_name" type="text"
                           value="<?php echo e(old('healthstatus_name', isset($healthstatusItem)? $healthstatusItem->name: '')); ?>">
                </div>
            </div>
        </div>
        <hr>
        <div class="form-actions">
            <button type="submit" class="btn btn-lg btn-success col-md-6 offset-md-3">
                <i class="icon-check"></i>
                ذخیره اطلاعات
            </button>
        </div>
    </form>
</div>
<?php /**PATH /home/fbcofmsf/fbportal.farazband.com/resources/views/admin/healthstatuses/form.blade.php ENDPATH**/ ?>