<div class="col-md-6 offset-md-3">
    <form id="simple-form" role="form" method="post" action="">
        <?php echo e(csrf_field()); ?>

        <div class="form-body">
            <div class="form-group">
                <label>انبار</label>
                <div class="input-group">
                    <select class="form-control select2" name="materialsheet_warehouse_id" id="materialsheet_warehouse_id" <?php echo e(isset($materialsheetItem) && $materialsheetItem instanceof \App\Models\Materialsheet ? 'disabled': ''); ?>>
                            <option value="0">انبار را انتخاب کنید.</option>
                        <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($warehouse->id); ?>" <?php echo e(isset($materialsheetItem) && $materialsheetItem->warehouse->id === $warehouse->id ? 'selected': ''); ?>><?php echo e($warehouse->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div><!-- /.input-group -->
            </div>
            <div class="form-group">
                <label>نوع</label>
                <div class="input-group">
                    <select class="form-control select2" name="materialsheet_type" id="materialsheet_type" <?php echo e(isset($materialsheetItem) && $materialsheetItem instanceof \App\Models\Materialsheet ? 'disabled': ''); ?>>
                        <option value="0">نوع را انتخاب کنید.</option>
                        <option value="1" <?php echo e(isset($materialsheetItem) && $materialsheetItem->type === 1 ? 'selected': ''); ?>>ورود کالا</option>
                        <option value="2" <?php echo e(isset($materialsheetItem) && $materialsheetItem->type === 2 ? 'selected': ''); ?>>خروج کالا</option>
                    </select>
                </div><!-- /.input-group -->
            </div>
            <div class="form-group">
                <label>نام مصالح</label>
                <div class="input-group">
                    <select class="form-control select2" name="materialsheet_material_id" id="materialsheet_material_id" <?php echo e(isset($materialsheetItem) && $materialsheetItem instanceof \App\Models\Materialsheet ? 'disabled': ''); ?>>
                        <option value="0">مصالح را انتخاب کنید.</option>
                        <?php if(isset($materialsheetItem) && $materialsheetItem instanceof \App\Models\Materialsheet): ?>
                            <option value="<?php echo e($materialsheetItem->material->id); ?>" selected><?php echo e($materialsheetItem->material->name); ?></option>
                        <?php endif; ?>
                        
                            
                        
                    </select>
                </div><!-- /.input-group -->
            </div>
            <div class="form-group">
                <label for="stock">مقدار
                    <small> (الزامی)</small>
                </label>
                <div class="input-group">
                    <input id="stock" class="form-control" name="stock" type="text"
                           value="<?php echo e(old('stock', isset($materialsheetItem)? $materialsheetItem->stock: '')); ?>">
                </div>
            </div>
        </div>
        <hr>
        <div class="form-actions">
            <button type="submit" class="btn btn-lg btn-success col-md-6 offset-md-3">
                <i class="icon-check"></i>
                ذخیره اطلاعات
            </button>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/materialsheets/form.blade.php ENDPATH**/ ?>