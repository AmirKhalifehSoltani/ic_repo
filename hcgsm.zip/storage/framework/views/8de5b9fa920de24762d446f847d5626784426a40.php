<?php $__env->startSection('content'); ?>
    <form method="get" id="simple-form" role="form">
        <div class="form-row">
            <div class="form-group col-md-3">
                <input type="text" name="search" id="search" class="form-control" placeholder="جستجو" value="<?php echo e(isset($search_phrase) && $search_phrase != ''? $search_phrase : ''); ?>"/>
            </div>
            <div class="form-group col-md-3">
                <select name="matcat" id="matcat" class="form-control select2">
                    <option value="0">انتخاب دسته مصالح</option>
                    <?php $__currentLoopData = $material_reports_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material_reports_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($material_reports_category->matcatid); ?>" <?php echo e(isset($matcat_id) && $matcat_id == $material_reports_category->matcatid ? 'selected' : ''); ?>><?php echo e($material_reports_category->matcatname); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-3">
                <select name="warehouse" id="warehouse" class="form-control select2">
                    <option value="0" selected>انتخاب انبار</option>
                    <?php $__currentLoopData = $material_reports_warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material_reports_warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($material_reports_warehouse->warehouse->id); ?>" <?php echo e(isset($warehouse_id) && $warehouse_id == $material_reports_warehouse->warehouse->id ? 'selected' : ''); ?>><?php echo e($material_reports_warehouse->warehouse->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-3">
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fa fa-search"></i>
                    جستجو
                </button>
            </div>
        </div>
    </form>
    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped">
            <thead>
            <tr>
                <th class="sorting" data-sorting_type="asc" data-column_name="report_material_id"
                    style="cursor: pointer">نام مصالح<span id="id_icon"></span></th>
                <th class="sorting" data-sorting_type="asc" data-column_name="matcat_name" style="cursor: pointer">دسته
                    مصالح<span id="post_title_icon"></span></th>
                <th class="sorting" data-sorting_type="asc" data-column_name="report_warehouse_id"
                    style="cursor: pointer">نام انبار
                </th>
                <th class="sorting" data-sorting_type="asc" data-column_name="report_stock" style="cursor: pointer">
                    موجودی (واحد)
                </th>
            </tr>
            </thead>
            <tbody>
            <?php if($materialreports_full_data && count($materialreports_full_data) > 0): ?>
                <?php echo $__env->make('admin.materialreports.row', $materialreports_full_data, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            </tbody>
        </table>
        <div class="page-pagination col-md-4 offset-md-4">
            <?php echo e($materialreports_full_data->links()); ?>

        </div>
        <input type="hidden" name="hidden_page" id="hidden_page" value="1"/>
        <input type="hidden" name="hidden_column_name" id="hidden_column_name" value="id"/>
        <input type="hidden" name="hidden_sort_type" id="hidden_sort_type" value="asc"/>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fbcofmsf/fbportal.farazband.com/resources/views/admin/materialreports/materials.blade.php ENDPATH**/ ?>