<!DOCTYPE html>
<html lang="fa" dir="rtl" class="rtl">
<head>
    <title>شمارنده بهراد</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="داشبورد مدیریتی دستگاه شمارنده تردد">
    <meta name="fontiran.com:license" content="NE29X">
    <link rel="shortcut icon" href="/images/favicon.png">

    <!-- BEGIN CSS -->
    <link href="/plugins/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/plugins/bootstrap-rtl/dist/css/bootstrap-rtl.min.css" rel="stylesheet">
    <link href="/plugins/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <link href="/plugins/simple-line-icons/css/simple-line-icons.min.css" rel="stylesheet">
    <link href="/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="/plugins/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css" rel="stylesheet">
    <link href="/plugins/switchery/dist/switchery.min.css" rel="stylesheet">
    <link href="/plugins/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
    <link href="/plugins/paper-ripple/dist/paper-ripple.min.css" rel="stylesheet">
    <link href="/plugins/iCheck/skins/square/_all.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <link href="/css/colors.css" rel="stylesheet">
    <link href="/css/custom-style.css" rel="stylesheet">
    <!-- END CSS -->

</head>
<body class="active-ripple theme-blue fix-header sidebar-extra">
<!-- BEGIN LOEADING -->
<div id="loader">
    <div class="spinner"></div>
</div><!-- /loader -->
<!-- END LOEADING -->

<!-- BEGIN HEADER -->
<div class="navbar navbar-fixed-top" id="main-navbar">
    <div class="header-right">
        <a href="dashboard.html" class="logo-con">
            <img src="/images/logo.png" class="img-responsive center-block" alt="لوگو قالب مدیران">
        </a>
    </div><!-- /.header-right -->
    <div class="header-left">
        <div class="top-bar">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="#" class="btn" id="toggle-sidebar">
                        <span></span>
                    </a>
                </li>
                <li>
                    <a href="#" class="btn open" id="toggle-sidebar-top">
                        <i class="icon-user-following"></i>
                    </a>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-left">
                <li class="dropdown dropdown-user">
                    <a class="dropdown-toggle dropdown-hover" href="<?php echo e(route('login')); ?>">
                        <span> ورود </span><i class="icon-login"></i>
                    </a>
                </li>
                <li class="dropdown dropdown-user">
                    <a class="dropdown-toggle dropdown-hover" href="<?php echo e(route('registeration')); ?>">
                        <span> ثبت نام </span><i class="fa fa-user-plus"></i>
                    </a>
                </li>
            </ul><!-- /.navbar-left -->
        </div><!-- /.top-bar -->
    </div><!-- /.header-left -->
</div><!-- /.navbar -->
<!-- END HEADER -->

<!-- BEGIN WRAPPER -->
<div id="wrapper">

    <!-- BEGIN SIDEBAR -->
    <div id="sidebar">
        <div class="sidebar-top">
            <div class="search-box">
                <form class="search-form" action="#" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control placeholder-light" placeholder="جستجو..." name="key">
                        <span class="input-group-btn">
                                    <button type="submit" class="btn btn-round submit">
                                        <i class="icon-magnifier"></i>
                                    </button>
                                </span>
                    </div>
                </form>
            </div><!-- /.search-box -->
            <div class="user-box">
                <a href="#">
                    <img src="/images/user/128.png" alt="عکس پروفایل" class="img-circle img-responsive">
                </a>
                <div class="user-details">
                    <h4>امیر سلطانی</h4>
                    <p class="role">مسئول فنی</p>
                </div><!-- /.user-details -->
            </div><!-- /.user-box -->
        </div><!-- /.sidebar-top -->
        <div class="side-menu-container">
            <ul class="metismenu" id="side-menu">
                <li>
                    <a href="<?php echo e(route('admin.users')); ?>" class="dropdown-toggle">
                        <i class="fa fa-user"></i>
                        <span>کاربران</span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('admin.users')); ?>">
                                <i class="fa fa-user"></i>
                                <span>لیست کاربران</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.users.create')); ?>">
                                <i class="fa fa-user-plus"></i>
                                <span>ثبت کاربر جدید</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(route('frontend.stats')); ?>" class="dropdown-toggle">
                        <i class="icon-chart"></i>
                        <span>آمار بازدید</span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('frontend.stats')); ?>">
                                <i class="icon-chart"></i>
                                <span>آمار بازدید روزانه</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(route('frontend.settings')); ?>">
                        <i class="icon-settings"></i>
                        <span>تنظیمات</span>
                    </a>
                </li>
            </ul><!-- /#side-menu -->
        </div><!-- /.side-menu-container -->
    </div><!-- /#sidebar -->
    <!-- END SIDEBAR -->

    <!-- BEGIN PAGE CONTENT -->
    <div id="page-content">
        <div class="row">
            <!-- BEGIN BREADCRUMB -->
            <div class="col-md-12">
                <div class="breadcrumb-box border shadow">
                    <ul class="breadcrumb">
                        <li><a href="#"></a></li>
                        <li><a href="#"></a></li>
                    </ul>
                    <div class="breadcrumb-left">
                        <span id="current-date"></span>
                        <i class="icon-calendar"></i>
                    </div><!-- /.breadcrumb-left -->
                </div><!-- /.breadcrumb-box -->
            </div><!-- /.col-md-12 -->
            <!-- END BREADCRUMB -->
            <div class="col-12">
                <div class="portlet box border shadow">
                    <div class="portlet-heading">
                        <div class="portlet-title">
                            <h3 class="title">
                                <i class="icon-chart"></i>
                                <?php echo e(isset($panel_title) ? $panel_title : ''); ?>

                            </h3>
                        </div><!-- /.portlet-title -->
                        <div class="buttons-box">
                            <a class="btn btn-sm btn-default btn-round btn-fullscreen" rel="tooltip" title="تمام صفحه"
                               href="#">
                                <i class="icon-size-fullscreen"></i>
                            </a>
                            <a class="btn btn-sm btn-default btn-round btn-collapse" rel="tooltip" title="کوچک کردن"
                               href="#">
                                <i class="icon-arrow-up"></i>
                            </a>
                        </div><!-- /.buttons-box -->
                    </div><!-- /.portlet-heading -->
                    <div class="portlet-body">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div><!-- /.portlet-body -->
            </div><!-- /.portlet -->
        </div><!-- /.col-12 -->
    </div><!-- /.row -->
</div><!-- /#page-content -->
<!-- END PAGE CONTENT -->

</div><!-- /#wrapper -->
<!-- END WRAPPER -->

<div class="row footer-container">
    <div class="col-md-12">
        <div class="copyright">
            <p class="pull-right">
                کلیه حقوق برای شرکت مهرآذین بهراد محفوظ است.
            </p>
            <p class="pull-left ltr tahoma">
                <span>©</span>
                <a href="http://Behrad.co">Behrad.co</a>
            </p>
        </div><!-- /.copyright -->
    </div><!-- /.col-md-12 -->
</div><!-- /.row -->

<!-- BEGIN SETTING -->
<div class="settings d-none d-sm-block">
    <a href="#" class="btn" id="toggle-setting">
        <i class="icon-settings"></i>
    </a>
    <h3 class="text-center">تنظیمات</h3>

    <div class="fix-header-box">
        <p class="h6">
            هدر ثابت:
            <span class="pull-left">
                        <input type="checkbox" class="fix-header-switch normal" checked>
                    </span>
        </p>
    </div><!-- /.fix-header-box -->
    <hr class="light">
    <div class="toggle-sidebar-box">
        <p class="h6">
            جمع کردن سایدبار:
            <span class="pull-left">
                        <input type="checkbox" class="toggle-sidebar-switch normal">
                    </span>
        </p>
    </div><!-- /.toggle-sidebar-box -->
    <hr class="light">
    <div class="toggle-sidebar-box">
        <p class="h6">
            سایدبار خلاقانه:
            <span class="pull-left">
                        <input type="checkbox" class="creative-sidebar-switch normal">
                    </span>
        </p>
    </div><!-- /.toggle-sidebar-box -->
    <hr class="light">
    <div class="theme-colors">
        <p class="h6">رنگ قالب : </p>
        <a class="btn btn-round btn-blue ripple-effect active" data-color="blue"></a>
        <a class="btn btn-round btn-red ripple-effect" data-color="red"></a>
        <a class="btn btn-round btn-green ripple-effect" data-color="green"></a>
        <a class="btn btn-round btn-orange ripple-effect" data-color="orange"></a>
        <a class="btn btn-round btn-darkblue ripple-effect" data-color="darkblue"></a>
        <a class="btn btn-round btn-purple ripple-effect" data-color="purple"></a>
    </div><!-- /.theme-colors -->
    <div class="theme-code ltr text-left">
        <code></code>
    </div><!-- /.theme-code -->
</div><!-- /.settings -->
<!-- END SETTING -->

<!-- BEGIN CODE MODAL -->
<div class="modal fade" id="code-modal" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn btn-default btn-round btn-icon pull-right" id="btn-copy"><i
                        class="fa fa-copy"></i></button>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">کپی کردن کدها</h4>
            </div>
            <div class="modal-body"></div>
        </div> <!-- /.modal-content -->
    </div> <!-- /.modal-dialog -->
</div> <!-- /.modal -->
<!-- END CODE MODAL -->

<!-- BEGIN JS -->
<script src="/plugins/jquery/dist/jquery-1.12.4.min.js"></script>
<script src="/plugins/jquery-migrate/jquery-migrate-1.2.1.min.js"></script>
<script src="/plugins/popper/popper.min.js"></script>
<script src="/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="/plugins/metisMenu/dist/metisMenu.min.js"></script>
<script src="/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js"></script>
<script src="/plugins/paper-ripple/dist/PaperRipple.min.js"></script>
<script src="/plugins/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="/plugins/sweetalert2/dist/sweetalert2.min.js"></script>
<script src="/plugins/screenfull/dist/screenfull.min.js"></script>
<script src="/plugins/iCheck/icheck.min.js"></script>
<script src="/plugins/switchery/dist/switchery.js"></script>
<script src="/plugins/persian-date/persian-date.min.js"></script>
<script src="/plugins/persian-datepicker/js/persian-datepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
<script src="/js/core.js"></script>
<script src="/js/pages/calendar.js"></script>
<script src="/js/custom.js"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\ccounter\resources\views/layouts/auth.blade.php ENDPATH**/ ?>