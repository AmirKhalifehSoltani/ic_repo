<?php $__currentLoopData = $equipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($equipment->full_name); ?></td>
        <td><?php echo e($equipment->equipcat->name); ?></td>
        <td><?php echo e($equipment->unit->name); ?></td>
        <td><?php echo e($equipment->sku); ?></td>
        <td><?php echo $__env->make('admin.equipments.operations', $equipment, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/fbcofmsf/fbportal.farazband.com/resources/views/admin/equipments/row.blade.php ENDPATH**/ ?>