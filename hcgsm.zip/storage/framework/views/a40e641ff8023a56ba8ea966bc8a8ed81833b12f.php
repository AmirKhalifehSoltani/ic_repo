<?php $__env->startSection('content'); ?>
<h2>This is test.</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hcgsm\resources\views/test.blade.php ENDPATH**/ ?>