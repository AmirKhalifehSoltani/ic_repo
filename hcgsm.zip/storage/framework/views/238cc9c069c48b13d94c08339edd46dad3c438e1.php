<?php $__currentLoopData = $counters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($counter->name); ?></td>
        <td><?php echo e($counter->branch['name']); ?></td>
        <td><?php echo $__env->make('frontend.counters.operations', $counter, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\ccounter\resources\views/frontend/counters/row.blade.php ENDPATH**/ ?>