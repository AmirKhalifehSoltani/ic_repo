<div class="col-md-6 offset-md-3">
    <form id="simple-form" role="form" method="post" action="">
        <?php echo e(csrf_field()); ?>

        <div class="form-body">
            <div class="form-group">
                <label for="equipment_name">نام تجهیز
                    <small> (الزامی)</small>
                </label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-user"></i>
                    </span>
                    <input id="equipment_name" class="form-control" name="equipment_name" type="text"
                           value="<?php echo e(old('equipment_name', isset($equipmentItem)? $equipmentItem->name: '')); ?>">
                </div>
            </div>
            <div class="form-body">
                <div class="form-group">
                    <label for="equipment_name">کد
                    </label>
                    <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-barcode"></i>
                    </span>
                        <input id="sku" class="form-control" name="sku" type="text"
                               value="<?php echo e(old('sku', isset($equipmentItem)? $equipmentItem->sku: '')); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label>دسته بندی</label>
                    <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-options"></i>
                    </span>
                        <select class="form-control" name="equipment_equipcat_id">
                            <option value="0">دسته‌بندی را انتخاب کنید.</option>
                            <?php $__currentLoopData = $equipcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($equipcat->id); ?>" <?php echo e(isset($equipmentItem) && $equipmentItem->equipcat->id === $equipcat->id ? 'selected': ''); ?>><?php echo e($equipcat->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div><!-- /.input-group -->
                </div>
                <div class="form-group">
                    <label>مشخصه فنی</label>
                    <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-options"></i>
                    </span>
                        <select class="form-control" name="equipment_techspec_id">
                        <option value="0">مشخصه فنی را انتخاب کنید.</option>
                        <?php $__currentLoopData = $techspecs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $techspec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            
                                <option value="<?php echo e($techspec->id); ?>" <?php echo e(isset($equipmentItem) && isset($equipmentItem->techspec) && $equipmentItem->techspec->id === $techspec->id ? 'selected': ''); ?>><?php echo e($techspec->name); ?></option>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div><!-- /.input-group -->
                </div>
                <div class="form-group">
                    <label>مشخصه ظاهری</label>
                    <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-options"></i>
                    </span>
                        <select class="form-control" name="equipment_lookspec_id">
                            <option value="0">مشخصه ظاهری را انتخاب کنید.</option>
                            <?php $__currentLoopData = $lookspecs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lookspec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                    <option value="<?php echo e($lookspec->id); ?>" <?php echo e(isset($equipmentItem) && isset($equipmentItem->lookspec) && $equipmentItem->lookspec->id === $lookspec->id ? 'selected': ''); ?>><?php echo e($lookspec->name); ?></option>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div><!-- /.input-group -->
                </div>
                <div class="form-group">
                    <label>وضعیت سلامتی</label>
                    <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-options"></i>
                    </span>
                        <select class="form-control" name="equipment_healthstatus_id">
                            <option value="0">وضعیت سلامتی را انتخاب کنید.</option>
                            <?php $__currentLoopData = $healthstatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $healthstatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                    <option value="<?php echo e($healthstatus->id); ?>" <?php echo e(isset($equipmentItem) && isset($equipmentItem->healthstatus) && $equipmentItem->healthstatus->id === $healthstatus->id ? 'selected': ''); ?>><?php echo e($healthstatus->name); ?></option>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div><!-- /.input-group -->
                </div>
                <div class="form-group">
                    <label>واحد</label>
                    <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-options"></i>
                    </span>
                        <select class="form-control" name="stock_unit">
                            <option value="0">واحد را انتخاب کنید.</option>
                            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($unit->id); ?>" <?php echo e(isset($equipmentItem) && $equipmentItem->unit->id === $unit->id ? 'selected': ''); ?>><?php echo e($unit->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div><!-- /.input-group -->
                </div>
            </div>
            <hr>
            <div class="form-actions">
                <button type="submit" class="btn btn-lg btn-success col-md-6 offset-md-3">
                    <i class="icon-check"></i>
                    ذخیره اطلاعات
                </button>
            </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/equipments/form.blade.php ENDPATH**/ ?>