<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped" id="admin_devices_table">
            <thead>
            <tr>
                <th>نام دستگاه</th>
                <th>کد دستگاه</th>
                <th>نام کاربر</th>
                <td>عملیات</td>
            </tr>
            </thead>
            <tbody>
            <?php if($devices && count($devices) > 0): ?>
                <?php echo $__env->make('admin.devices.row', $devices, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="3" style="text-align: center">دستگاهی وجود ندارد!</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hcgsm\resources\views/admin/devices/devices.blade.php ENDPATH**/ ?>