<div id="sidebar">
    <?php if(Auth::check()): ?>
        <div class="sidebar-top">
            <div class="search-box">
                <form class="search-form" action="#" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control placeholder-light" placeholder="جستجو..." name="key">
                        <span class="input-group-btn">
                                        <button type="submit" class="btn btn-round submit">
                                            <i class="icon-magnifier"></i>
                                        </button>
                                    </span>
                    </div>
                </form>
            </div><!-- /.search-box -->
            <div class="user-box">
                <a href="#">
                    <img src="/images/user/man.png" alt="عکس پروفایل" class="img-circle img-responsive">
                </a>
                <div class="user-details">
                    <h4><?php echo e(isset(Auth::user()->first_name) ? Auth::user()->first_name : 'حساب کاربری'); ?></h4>

                </div><!-- /.user-details -->
            </div><!-- /.user-box -->
        </div><!-- /.sidebar-top -->
        <div class="side-menu-container">
            <ul class="metismenu" id="side-menu">
                <?php if(Auth::user()->role === 1): ?>
                    <li>
                        <a href="<?php echo e(route('admin.users')); ?>" class="dropdown-toggle">
                            <i class="fa fa-user"></i>
                            <span>کاربران</span>
                        </a>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('admin.users')); ?>">
                                    <i class="fa fa-user"></i>
                                    <span>لیست کاربران</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.users.create')); ?>">
                                    <i class="fa fa-user-plus"></i>
                                    <span>ثبت کاربر جدید</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->role === 0): ?>
                    <li>
                        <a href="<?php echo e(route('frontend.dashboard')); ?>">
                            <i class="fa fa-dashboard"></i>
                            <span>پیشخوان</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('frontend.stats')); ?>">
                            <i class="icon-chart"></i>
                            <span>آمار تفصیلی</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('branches.list')); ?>" class="dropdown-toggle">
                            <i class="fa fa-building"></i>
                            <span>شعب</span>
                        </a>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('branches.list')); ?>">
                                    <span>لیست شعب</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('branches.create')); ?>">
                                    <span>ثبت شعبه جدید</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="<?php echo e(route('counters.list')); ?>" class="dropdown-toggle">
                            <i class="fa fa-hdd-o"></i>
                            <span>شمارنده‌ها</span>
                        </a>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('counters.list')); ?>">
                                    <span>لیست شمارنده‌ها</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('counters.create')); ?>">
                                    <span>ثبت شمارنده جدید</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="<?php echo e(route('frontend.settings')); ?>">
                            <i class="icon-settings"></i>
                            <span>تنظیمات</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul><!-- /#side-menu -->
        </div><!-- /.side-menu-container -->
    <?php endif; ?>
</div><!-- /#sidebar -->
<?php /**PATH C:\xampp-new\htdocs\ccounter\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>