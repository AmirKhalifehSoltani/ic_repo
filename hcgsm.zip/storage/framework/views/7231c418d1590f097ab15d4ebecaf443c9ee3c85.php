<?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($log->id); ?></td>
        <td><?php echo e($log->operation_type); ?></td>
        <td><?php echo e($log->operation_subject_id); ?></td>
        <td><?php echo e($log->user->first_name.' '.$log->user->last_name); ?></td>
        <td><?php echo e($log->created_at); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/logs/row.blade.php ENDPATH**/ ?>