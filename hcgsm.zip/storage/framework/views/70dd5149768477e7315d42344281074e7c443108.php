<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped" id="equipmentsheet_table">
        
            <thead>
            <tr>
                <th>تاریخ</th>
                <th>نوع</th>
                <th>انبار</th>
                <th>نام تجهیزات</th>
                <th>مقدار (واحد)</th>
                <th>کاربر</th>
                <th>مقصد</th>
                <?php if(\Illuminate\Support\Facades\Auth::user()->role === 1): ?>
                    <th>عملیات</th>
                <?php endif; ?>
            </tr>
            </thead>
            <tbody>
            <?php if($equipmentsheets && count($equipmentsheets) > 0): ?>
                <?php echo $__env->make('admin.equipmentsheets.row', $equipmentsheets, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            </tbody>
        </table>
        <div class="page-pagination col-md-4 offset-md-4">
            <?php echo e($equipmentsheets->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fbcofmsf/fbportal.farazband.com/resources/views/admin/equipmentsheets/equipmentsheets.blade.php ENDPATH**/ ?>