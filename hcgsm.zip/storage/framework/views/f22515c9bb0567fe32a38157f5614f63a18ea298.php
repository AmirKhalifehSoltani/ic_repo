<?php $__currentLoopData = $equipmentsheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipmentsheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    if (isset($equipmentsheet->type) && $equipmentsheet->type === 1) {
        $equipmentsheet_type_name = 'ورود';
    } elseif (isset($equipmentsheet->type) && $equipmentsheet->type === 2) {
        $equipmentsheet_type_name = 'خروج';
    }

    if($equipmentsheet) {
        if(!$equipmentsheet->user) {
            $equipsheet_user_name = 'نامعلوم';
        } elseif($equipmentsheet->user) {
            $equipsheet_user_name = $equipmentsheet->user->first_name.' '.$equipmentsheet->user->last_name;
        }

        $next_warehouse_id = $equipmentsheet->next_warehouse_id;
        $next_warehouse = \App\Models\Warehouse::find($next_warehouse_id);
        if (!$next_warehouse){
            $next_warehouse_name = '-';
        } else {
            $next_warehouse_name = $next_warehouse->name;
        }
    }

    ?>
    <script> var myDate = new persianDate.unix(<?php echo e($equipmentsheet->created_at->timestamp); ?>).format("dddd, DD MMMM YY, H:mm:ss") </script>
    <tr>
        <td>
            <script>document.write(myDate)</script>
        </td>
        <td><?php echo e($equipmentsheet_type_name); ?></td>
        <td><?php echo e($equipmentsheet->warehouse->name); ?></td>
        <td><?php echo e($equipmentsheet->equipment->name); ?></td>
        <td><?php echo e($equipmentsheet->stock); ?> (<?php echo e($equipmentsheet->equipment->unit->name); ?>)</td>
        <td><?php echo e(isset($equipsheet_user_name)? $equipsheet_user_name: ''); ?></td>
        <td><?php echo e($next_warehouse_name); ?></td>
        <?php if(\Illuminate\Support\Facades\Auth::user()->role === 1): ?>
            <td><?php echo $__env->make('admin.equipmentsheets.operations', $equipmentsheet, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
        <?php endif; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/fbcofmsf/fbportal.farazband.com/resources/views/admin/equipmentsheets/row.blade.php ENDPATH**/ ?>