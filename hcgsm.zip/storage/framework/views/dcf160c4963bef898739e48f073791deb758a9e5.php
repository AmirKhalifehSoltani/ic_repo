<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped" id="admin_users_table">
            <thead>
            <tr>
                <th>نام واحد</th>
                <td>عملیات</td>
            </tr>
            </thead>
            <tbody>
            <?php if($units && count($units) > 0): ?>
                <?php echo $__env->make('admin.units.row', $units, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fbcofmsf/fbportal.farazband.com/resources/views/admin/units/units.blade.php ENDPATH**/ ?>