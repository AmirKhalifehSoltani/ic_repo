<?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($material->name); ?></td>
        <td><?php echo e($material->matcat->name); ?></td>
        <td><?php echo e($material->unit->name); ?></td>
        
        
        <td><?php echo $__env->make('admin.materials.operations', $material, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/materials/row.blade.php ENDPATH**/ ?>