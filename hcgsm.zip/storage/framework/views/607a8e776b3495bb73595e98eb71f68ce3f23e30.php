<?php if($user->id == 6): ?>
    <a href="#" class="btn btn-secondary" title="ویرایش"><i class="icon-pencil"></i></a>
    <a href="#" class="btn btn-secondary" title="حذف"><i class="icon-trash"></i></a>
<?php else: ?>
<a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-info" title="ویرایش"><i class="icon-pencil"></i></a>
<a href="<?php echo e(route('admin.users.delete', $user->id)); ?>" onclick="return confirm('آیا از حذف دستگاه مطمئن هستید؟')" class="btn btn-danger" title="حذف"><i class="icon-trash"></i></a>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\hcgsm\resources\views/admin/users/operations.blade.php ENDPATH**/ ?>