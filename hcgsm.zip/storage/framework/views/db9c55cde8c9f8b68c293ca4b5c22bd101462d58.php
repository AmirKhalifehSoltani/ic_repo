<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.equipmentreports.searchfilter_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped">
            <thead>
            <tr>
                <th class="sorting" data-sorting_type="asc" data-column_name="report_equipment_id">کد | نام کالاها (فنی - ظاهری - سلامتی)<span id="id_icon"></span></th>
                <th class="sorting" data-sorting_type="asc" data-column_name="equipcat_name">دسته تجهیزات<span id="post_title_icon"></span></th>
                <th class="sorting" data-sorting_type="asc" data-column_name="report_warehouse_id">نام انبار</th>
                <th class="sorting" data-sorting_type="asc" data-column_name="report_stock">موجودی (واحد)</th>
                
                
                
            </tr>
            </thead>
            <tbody>
            <?php if($equipmentreports_full_data && count($equipmentreports_full_data) > 0): ?>
                <?php echo $__env->make('admin.equipmentreports.row', $equipmentreports_full_data, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            </tbody>
        </table>
        <div class="page-pagination col-md-4 offset-md-4">
            <?php echo e($equipmentreports_full_data->links()); ?>

        </div>
        <input type="hidden" name="hidden_page" id="hidden_page" value="1"/>
        <input type="hidden" name="hidden_column_name" id="hidden_column_name" value="id"/>
        <input type="hidden" name="hidden_sort_type" id="hidden_sort_type" value="asc"/>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fbcofmsf/fbportal.farazband.com/resources/views/admin/equipmentreports/equipments.blade.php ENDPATH**/ ?>