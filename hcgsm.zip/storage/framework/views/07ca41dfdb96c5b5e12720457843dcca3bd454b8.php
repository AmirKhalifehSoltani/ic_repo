<div class="col-md-6 offset-md-3">
    <form id="simple-form" role="form" method="post" action="">
        <?php echo e(csrf_field()); ?>

        <div class="form-body">
            <div class="form-group">
                <label for="matcat_name">نام دسته مصالح <small> (الزامی)</small></label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-user"></i>
                    </span>
                    <input id="matcat_name" class="form-control" name="matcat_name" type="text"
                           value="<?php echo e(old('matcat_name', isset($matcatItem)? $matcatItem->name: '')); ?>">
                </div>
            </div>
        </div>
        <hr>
        <div class="form-actions">
            <button type="submit" class="btn btn-lg btn-success col-md-6 offset-md-3">
                <i class="icon-check"></i>
                ذخیره اطلاعات
            </button>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/matcats/form.blade.php ENDPATH**/ ?>