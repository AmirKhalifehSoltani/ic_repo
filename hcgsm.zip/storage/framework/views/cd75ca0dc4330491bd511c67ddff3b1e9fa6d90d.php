<?php $__currentLoopData = $techspecs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $techspec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($techspec->name); ?></td>
        <td><?php echo $__env->make('admin.techspecs.operations', $techspec, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/techspecs/row.blade.php ENDPATH**/ ?>