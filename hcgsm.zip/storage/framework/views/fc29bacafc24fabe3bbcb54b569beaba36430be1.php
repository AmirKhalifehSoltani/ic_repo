<div class="col-md-6 offset-md-3">
    <form id="simple-form" role="form" method="post" action="">
        <?php echo e(csrf_field()); ?>

        <div class="form-body">
            <div class="form-group">
                <label for="material_name">نام مصالح
                    <small> (الزامی)</small>
                </label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-user"></i>
                    </span>
                    <input id="material_name" class="form-control" name="material_name" type="text"
                           value="<?php echo e(old('material_name', isset($materialItem)? $materialItem->name: '')); ?>">
                </div>
            </div>
            <div class="form-group">
                <label>دسته بندی</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-options"></i>
                    </span>
                    <select class="form-control" name="material_matcat_id">
                        <?php $__currentLoopData = $matcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($matcat->id); ?>" <?php echo e(isset($materialItem) && $materialItem->matcat->id === $matcat->id ? 'selected': ''); ?>><?php echo e($matcat->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div><!-- /.input-group -->
            </div>
            
                
                
                    
                        
                    
                    
                        
                        
                            
                        
                    
                
            
            <div class="form-group">
                <label>واحد</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-options"></i>
                    </span>
                    <select class="form-control" name="stock_unit">
                        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($unit->id); ?>" <?php echo e(isset($materialItem) && $materialItem->unit->id === $unit->id ? 'selected': ''); ?>><?php echo e($unit->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div><!-- /.input-group -->
            </div>
            
                
                    
                
                
                    
                        
                    
                    
                           
                
            
        </div>
        <hr>
        <div class="form-actions">
            <button type="submit" class="btn btn-lg btn-success col-md-6 offset-md-3">
                <i class="icon-check"></i>
                ذخیره اطلاعات
            </button>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/materials/form.blade.php ENDPATH**/ ?>