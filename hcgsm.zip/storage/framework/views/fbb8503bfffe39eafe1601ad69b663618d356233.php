<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if($my_devices && count($my_devices) > 0): ?>
            <?php $__currentLoopData = $my_devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $my_device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card_wrap col-md-4 col-sm-12">
                    <div class="row card_content_row">
                        <a class="card_wrap" href="<?php echo e(route('frontend.mysingledevice', $my_device->id)); ?>">
                            <div class="col-8 pull-right">
                                <?php echo e(isset($my_device->name)? $my_device->name: ''); ?>

                            </div>
                            <div class="col-4 pull-left">
                                <?php echo e(isset($my_device->temp)? $my_device->temp: ''); ?>

                            </div>
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-info">
                    دستگاهی برای حساب کاربری شما تنظیم نشده است.
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hcgsm\resources\views/frontend/devices/list.blade.php ENDPATH**/ ?>