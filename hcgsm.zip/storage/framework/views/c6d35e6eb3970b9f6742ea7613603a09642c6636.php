<div class="navbar navbar-fixed-top" id="main-navbar">
    <div class="header-right">
        <a href="<?php echo e(route('admin.users')); ?>" class="logo-con">
            <img src="/images/farazbandlogo2.png" class="img-responsive center-block">
        </a>
    </div><!-- /.header-right -->
    <div class="header-left">
        <div class="top-bar">
            <?php if(Auth::check()): ?>
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="#" class="btn" id="toggle-sidebar">
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="btn open" id="toggle-sidebar-top">
                            <i class="icon-user-following"></i>
                        </a>
                    </li>
                </ul>
                
                    
                    
                
                <ul class="nav navbar-nav navbar-left">
                    <li class="show_current_date">
                        <a href="#">
                            <span id="current-date"></span>
                            <i class="btn icon-calendar"></i>
                        </a>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="btn" id="toggle-fullscreen">
                            <i class="icon-size-fullscreen"></i>
                        </a>
                    </li>
                    <li class="dropdown dropdown-user">
                        <a href="#" class="dropdown-toggle dropdown-hover" data-toggle="dropdown">
                            <img src="/images/user/man48.png" alt="عکس پرفایل" class="img-circle img-responsive">
                            <span><?php echo e(isset(Auth::user()->first_name) ? Auth::user()->first_name : 'حساب کاربری'); ?></span>
                            <i class="icon-arrow-down"></i>
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="<?php echo e(route('logout')); ?>">
                                    <i class="icon-power"></i>
                                    خروج
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul><!-- /.navbar-left -->
            <?php else: ?>
                <ul class="nav navbar-nav navbar-left">
                    <li class="dropdown dropdown-user">
                        <a class="dropdown-toggle dropdown-hover" href="<?php echo e(route('login')); ?>">
                            <span> ورود </span><i class="icon-login"></i>
                        </a>
                    </li>
                    
                        
                            
                        
                    
                </ul><!-- /.navbar-left -->
            <?php endif; ?>
        </div><!-- /.top-bar -->
    </div><!-- /.header-left -->
</div><!-- /.navbar --><?php /**PATH C:\xampp\htdocs\fbportal\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>