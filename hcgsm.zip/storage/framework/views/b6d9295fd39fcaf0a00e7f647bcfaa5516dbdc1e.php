<?php if(session('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e(session('success')); ?></p>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp-new\htdocs\ccounter\resources\views/layouts/partials/notifications.blade.php ENDPATH**/ ?>