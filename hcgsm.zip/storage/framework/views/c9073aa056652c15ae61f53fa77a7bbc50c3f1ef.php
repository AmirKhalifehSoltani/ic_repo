<div class="col-md-6 offset-md-3">
    <form id="simple-form" role="form" method="post" action="">
        <?php echo e(csrf_field()); ?>

        <div class="form-body">
            <div class="form-group">
                <label for="techspec_name">نام مشخصه فنی <small> (الزامی)</small></label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-user"></i>
                    </span>
                    <input id="techspec_name" class="form-control" name="techspec_name" type="text"
                           value="<?php echo e(old('techspec_name', isset($techspecItem)? $techspecItem->name: '')); ?>">
                </div>
            </div>
        </div>
        <hr>
        <div class="form-actions">
            <button type="submit" class="btn btn-lg btn-success col-md-6 offset-md-3">
                <i class="icon-check"></i>
                ذخیره اطلاعات
            </button>
        </div>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/techspecs/form.blade.php ENDPATH**/ ?>