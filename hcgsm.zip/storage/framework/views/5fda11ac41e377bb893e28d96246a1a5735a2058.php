<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.equipments.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fbcofmsf/fbportal.farazband.com/resources/views/admin/equipments/edit.blade.php ENDPATH**/ ?>