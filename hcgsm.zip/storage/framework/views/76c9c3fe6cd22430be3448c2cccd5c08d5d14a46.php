<div id="sidebar">
    <?php if(Auth::check()): ?>
        <div class="sidebar-top">
            <div class="user-box">
                <a href="#">
                    <img src="/images/user/man.png" alt="عکس پروفایل" class="img-circle img-responsive">
                </a>
                <div class="user-details">
                    <h4><?php echo e(isset(Auth::user()->first_name) ? Auth::user()->first_name : 'حساب کاربری'); ?></h4>
                    
                </div><!-- /.user-details -->
            </div><!-- /.user-box -->
        </div><!-- /.sidebar-top -->
        <div class="side-menu-container">
            <ul class="metismenu" id="side-menu">
                <?php if(Auth::user()->role === 1): ?>
                    <li>
                        <a href="<?php echo e(route('admin.users')); ?>">
                            <i class="fa fa-user"></i>
                            <span>مدیریت کاربران</span>
                        </a>
                    </li>
                <?php endif; ?>
                <li>
                    <a href="<?php echo e(route('admin.equipmentreports')); ?>">
                        <i class="fa fa-wpforms"></i>
                        <span>گزارش موجودی</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.equipmentsheets')); ?>">
                        <i class="fa fa-drivers-license-o"></i>
                        <span>برگه‌های ورود/خروج</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.equipments')); ?>">
                        <i class="fa fa-wrench"></i>
                        <span>مدیریت کالاها</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.warehouses')); ?>">
                        <i class="fa fa-home"></i>
                        <span>مدیریت انبارها</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.equipcats')); ?>">
                        <i class="fa fa-bars"></i>
                        <span>مدیریت دسته‌بندی‌ها</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.units')); ?>">
                        <i class="fa fa-arrows-h"></i>
                        <span>مدیریت واحدها</span>
                    </a>
                </li>
                <li>
                    <a href="#" class="dropdown-toggle">
                        <i class="fa fa-certificate"></i>
                        <span>مشخصات تجهیزات</span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e(route('admin.techspecs')); ?>">
                                <span>مدیریت مشخصات فنی</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.lookspecs')); ?>">
                                <span>مدیریت مشخصات ظاهری</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.healthstatuses')); ?>">
                                <span>مدیریت وضعیت‌ سلامت</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul><!-- /#side-menu -->
        </div><!-- /.side-menu-container -->
    <?php endif; ?>
</div><!-- /#sidebar -->
<?php /**PATH C:\xampp\htdocs\fbportal\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>