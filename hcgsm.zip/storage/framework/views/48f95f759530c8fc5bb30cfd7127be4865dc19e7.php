<!DOCTYPE html>
<html lang="fa" dir="rtl" class="rtl">
<head>
    <title>شمارنده بهراد</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="داشبورد مدیریتی دستگاه شمارنده تردد">
    <meta name="fontiran.com:license" content="NE29X">
    <link rel="shortcut icon" href="/images/favicon.png">

    <!-- BEGIN CSS -->
    <link href="/plugins/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/plugins/bootstrap-rtl/dist/css/bootstrap-rtl.min.css" rel="stylesheet">
    <link href="/plugins/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <link href="/plugins/simple-line-icons/css/simple-line-icons.min.css" rel="stylesheet">
    <link href="/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="/plugins/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css" rel="stylesheet">
    <link href="/plugins/switchery/dist/switchery.min.css" rel="stylesheet">
    <link href="/plugins/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
    <link href="/plugins/paper-ripple/dist/paper-ripple.min.css" rel="stylesheet">
    <link href="/plugins/iCheck/skins/square/_all.css" rel="stylesheet">
    <link href="/plugins/data-table/DataTables-1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <link href="/css/colors.css" rel="stylesheet">
    <link href="/css/custom-style.css" rel="stylesheet">
    <!-- END CSS -->

</head>
<body class="active-ripple theme-darkblue fix-header sidebar-extra">
<!-- BEGIN LOEADING -->
<div id="loader">
    <div class="spinner"></div>
</div><!-- /loader -->
<!-- END LOEADING -->

<!-- BEGIN HEADER -->
<?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- END HEADER -->

<!-- BEGIN WRAPPER -->
<div id="wrapper">

    <!-- BEGIN SIDEBAR -->
        <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END SIDEBAR -->

    <!-- BEGIN PAGE CONTENT -->
    <div id="page-content">
        <div class="row">
            <!-- BEGIN BREADCRUMB -->
            <div class="col-md-12">
                <div class="breadcrumb-box border shadow">
                    <ul class="breadcrumb">
                        <li><a href="#"></a></li>
                        <li><a href="#"></a></li>
                    </ul>
                    <div class="breadcrumb-left">
                        <span id="current-date"></span>
                        <i class="icon-calendar"></i>
                    </div><!-- /.breadcrumb-left -->
                </div><!-- /.breadcrumb-box -->
            </div><!-- /.col-md-12 -->
            <!-- END BREADCRUMB -->
            <div class="col-12">
                <div class="portlet box border shadow">
                    <div class="portlet-heading">
                        <div class="portlet-title">
                            <h3 class="title">
                                <i class="icon-chart"></i>
                                <?php echo e(isset($panel_title) ? $panel_title : ''); ?>

                            </h3>
                        </div><!-- /.portlet-title -->
                        <div class="buttons-box">
                            <a class="btn btn-sm btn-default btn-round btn-fullscreen" rel="tooltip" title="تمام صفحه"
                               href="#">
                                <i class="icon-size-fullscreen"></i>
                            </a>
                            <a class="btn btn-sm btn-default btn-round btn-collapse" rel="tooltip" title="کوچک کردن"
                               href="#">
                                <i class="icon-arrow-up"></i>
                            </a>
                        </div><!-- /.buttons-box -->
                    </div><!-- /.portlet-heading -->
                    <div class="portlet-body">
                        <?php echo $__env->make('layouts.partials.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('frontend.partials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div><!-- /.portlet-body -->
            </div><!-- /.portlet -->
        </div><!-- /.col-12 -->
    </div><!-- /.row -->
</div><!-- /#page-content -->
<!-- END PAGE CONTENT -->

</div><!-- /#wrapper -->
<!-- END WRAPPER -->

<div class="row footer-container">
    <div class="col-md-12">
        <div class="copyright">
            <p class="pull-right">
                کلیه حقوق برای شرکت مهرآذین بهراد محفوظ است.
            </p>
            <p class="pull-left ltr tahoma">
                <span>©</span>
                <a href="http://Behrad.co">Behrad.co</a>
            </p>
        </div><!-- /.copyright -->
    </div><!-- /.col-md-12 -->
</div><!-- /.row -->

<!-- BEGIN SETTING -->

<!-- END SETTING -->

<!-- BEGIN CODE MODAL -->
<div class="modal fade" id="code-modal" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn btn-default btn-round btn-icon pull-right" id="btn-copy"><i
                        class="fa fa-copy"></i></button>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">کپی کردن کدها</h4>
            </div>
            <div class="modal-body"></div>
        </div> <!-- /.modal-content -->
    </div> <!-- /.modal-dialog -->
</div> <!-- /.modal -->
<!-- END CODE MODAL -->

<!-- BEGIN JS -->
<script src="/plugins/jquery/dist/jquery-1.12.4.min.js"></script>
<script src="/plugins/jquery-migrate/jquery-migrate-1.2.1.min.js"></script>
<script src="/plugins/popper/popper.min.js"></script>
<script src="/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="/plugins/metisMenu/dist/metisMenu.min.js"></script>
<script src="/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js"></script>
<script src="/plugins/paper-ripple/dist/PaperRipple.min.js"></script>
<script src="/plugins/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="/plugins/sweetalert2/dist/sweetalert2.min.js"></script>
<script src="/plugins/screenfull/dist/screenfull.min.js"></script>
<script src="/plugins/iCheck/icheck.min.js"></script>
<script src="/plugins/switchery/dist/switchery.js"></script>
<script src="/plugins/persian-date/persian-date.min.js"></script>
<script src="/plugins/persian-datepicker/js/persian-datepicker.min.js"></script>
<script src="/plugins/data-table/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
<script src="/js/core.js"></script>
<script src="/js/pages/calendar.js"></script>
<script src="/js/pages/datatable.js"></script>
<script src="/js/custom.js"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\ccounter\resources\views/layouts/admin.blade.php ENDPATH**/ ?>