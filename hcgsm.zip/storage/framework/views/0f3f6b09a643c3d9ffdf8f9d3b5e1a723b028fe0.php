<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped" id="materialsheet_table">
            <thead>
            <tr>
                <th>تاریخ</th>
                <th>نوع</th>
                <th>انبار</th>
                <th>نام مصالح</th>
                <th>مقدار (واحد)</th>
                <th>کاربر</th>
                <?php if(\Illuminate\Support\Facades\Auth::user()->role === 1): ?>
                    <th>عملیات</th>
                <?php endif; ?>
            </tr>
            </thead>
            <tbody>
            <?php if($materialsheets && count($materialsheets) > 0): ?>
                <?php echo $__env->make('admin.materialsheets.row', $materialsheets, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fbportal\resources\views/admin/materialsheets/equipmentsheets.blade.php ENDPATH**/ ?>