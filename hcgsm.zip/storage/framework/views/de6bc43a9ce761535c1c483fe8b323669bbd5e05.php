<?php $__env->startSection('content'); ?>
    <div class="col-md-6 offset-md-3">
        <?php if(session('loginError')): ?>
            <div class="alert alert-info">
                <p><?php echo e(session('loginError')); ?></p>
            </div>
        <?php endif; ?>
        <?php if(isset($msg)): ?>
            <div class="alert alert-info">
                <p><?php echo e($msg); ?></p>
            </div>
        <?php endif; ?>
        <form id="simple-form" role="form" method="post" action="<?php echo e(route('dologin')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-body">
                <div class="form-group">
                    <label for="user_name">نام کاربری <small> (الزامی)</small></label>
                    <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-user"></i>
                    </span>
                        <input id="user_name" class="form-control" name="user_name" type="text" value="<?php echo e(old('user_name')); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="password">رمز عبور<small>(الزامی حداقل 5 کاراکتر)</small></label>
                    <div class="input-group">
                    <span class="input-group-addon">
                        <i class="icon-key"></i>
                    </span>
                        <input type="password" id="password" minlength="5" class="form-control" name="password">
                    </div>
                </div>
            </div>
            <hr>
            <div class="form-actions">
                <button type="submit" class="btn btn-lg btn-info col-md-6 offset-md-3">
                    <i class="icon-check"></i>
                    ورود
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-new\htdocs\ccounter\resources\views/frontend/users/login.blade.php ENDPATH**/ ?>