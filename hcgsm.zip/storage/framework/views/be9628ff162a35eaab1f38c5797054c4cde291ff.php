<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if($device_btns && count($device_btns) > 0): ?>
            <?php $__currentLoopData = $device_btns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device_btn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card_wrap col-md-4 col-sm-12">
                    <div class="row card_content_row">
                        <div class="col-8">
                            <?php echo e(isset($device_btn->name)? $device_btn->name: ''); ?>

                        </div>
                        <div class="col-4">
                            <input type="checkbox" id="switchId-<?php echo e(isset($device_btn->id)? $device_btn->id: ''); ?>"
                                   class="js-switch" <?php echo e(isset($device_btn->status) && $device_btn->status == 1 ? 'checked': ''); ?> />
                            
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-info">
                    دکمه‌ای برای این دستگاه تنظیم نشده است.
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hcgsm\resources\views/frontend/devices/single.blade.php ENDPATH**/ ?>