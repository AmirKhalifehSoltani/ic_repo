<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-4 col-6">
            <div class="stat-box bg-blue shadow">
                <a href="#">
                    <div class="stat">
                        <div class="counter-down" data-value="2048">
                            <div class="num">2</div>
                            <div class="num">0</div>
                            <div class="num">4</div>
                            <div class="num">8</div>
                        </div>
                        <div class="h3">تعداد بازدید روز گذشته</div>
                    </div><!-- /.stat -->
                    <div class="visual">
                        <i class="icon-eye"></i>
                    </div><!-- /.visual -->
                </a>
            </div>
        </div>
        <div class="col-lg-4 col-6">
            <div class="stat-box bg-red shadow">
                <a href="#">
                    <div class="stat">
                        <div class="counter-down" data-value="2048">
                            <div class="num">2</div>
                            <div class="num">0</div>
                            <div class="num">4</div>
                            <div class="num">8</div>
                        </div>
                        <div class="h3">تعداد بازدید ۷ روز گذشته</div>
                    </div><!-- /.stat -->
                    <div class="visual">
                        <i class="icon-eye"></i>
                    </div><!-- /.visual -->
                </a>
            </div>
        </div>
        <div class="col-lg-4 col-6">
            <div class="stat-box bg-orange shadow">
                <a href="#">
                    <div class="stat">
                        <div class="counter-down" data-value="2048">
                            <div class="num">2</div>
                            <div class="num">0</div>
                            <div class="num">4</div>
                            <div class="num">8</div>
                        </div>
                        <div class="h3">تعداد بازدید ۳۰ روز گذشته</div>
                    </div><!-- /.stat -->
                    <div class="visual">
                        <i class="icon-eye"></i>
                    </div><!-- /.visual -->
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp-new\htdocs\ccounter\resources\views/frontend/dashboard/dashboard.blade.php ENDPATH**/ ?>