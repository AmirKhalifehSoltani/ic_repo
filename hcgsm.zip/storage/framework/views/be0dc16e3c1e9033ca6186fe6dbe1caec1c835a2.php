<?php $__currentLoopData = $equipmentreports_full_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipmetreport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($equipmetreport->equipsku.' | '.$equipmetreport->equipfullname); ?></td>
        <td><?php echo e($equipmetreport->equipcatname); ?></td>
        <td><?php echo e($equipmetreport->warehousename); ?></td>
        <td><?php echo e($equipmetreport->report_stock); ?> (<?php echo e($equipmetreport->unitname); ?>)</td>
        
        
        
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/fbcofmsf/fbportal.farazband.com/resources/views/admin/equipmentreports/row.blade.php ENDPATH**/ ?>